@extends('admin/template/main')
@section('title', 'Home')
@section('content')
<h1>Dashboard</h1>
@endsection